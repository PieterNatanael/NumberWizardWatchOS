//
//  NumberWizardWatchOSApp.swift
//  NumberWizardWatchOS Watch App
//
//  Created by Pieter Yoshua Natanael on 25/09/23.
//

import SwiftUI

@main
struct NumberWizardWatchOS_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
